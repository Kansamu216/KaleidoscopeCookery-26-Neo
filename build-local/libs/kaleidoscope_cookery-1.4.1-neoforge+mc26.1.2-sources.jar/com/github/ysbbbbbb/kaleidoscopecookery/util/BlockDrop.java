package com.github.ysbbbbbb.kaleidoscopecookery.util;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.Level;

public final class BlockDrop {
   private BlockDrop() {
   }

   public static void popResource(Level level, BlockPos pos, double yOffset, ItemStack stack) {
      if (level instanceof ServerLevel serverLevel
         && !stack.isEmpty()
         && serverLevel.getGameRules().get(GameRules.BLOCK_DROPS)
         && !level.restoringBlockSnapshots) {
         double itemHalfHeight = EntityType.ITEM.getHeight() / 2.0;
         double range = 0.1;
         double x = pos.getX() + 0.5 + Mth.nextDouble(level.getRandom(), -range, range);
         double y = pos.getY() + 0.5 + Mth.nextDouble(level.getRandom(), -range, range) - itemHalfHeight + yOffset;
         double z = pos.getZ() + 0.5 + Mth.nextDouble(level.getRandom(), -range, range);
         ItemEntity itemEntity = new ItemEntity(level, x, y, z, stack);
         itemEntity.setDefaultPickUpDelay();
         level.addFreshEntity(itemEntity);
      }
   }
}
