package com.github.ysbbbbbb.kaleidoscopecookery.crafting.serializer;

import com.github.ysbbbbbb.kaleidoscopecookery.crafting.recipe.StockpotRecipe;
import com.github.ysbbbbbb.kaleidoscopecookery.crafting.recipe.StockpotVisuals;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModSoupBases;
import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.ItemLike;

public final class StockpotRecipeSerializer {
   public static final int DEFAULT_TIME = 300;
   public static final Ingredient DEFAULT_CARRIER = Ingredient.of(new ItemLike[]{Items.BOWL});
   public static final Identifier DEFAULT_SOUP_BASE = ModSoupBases.WATER;
   public static final Identifier EMPTY_ID = Identifier.fromNamespaceAndPath("kaleidoscope_cookery", "stockpot/empty");
   public static final MapCodec<StockpotRecipe> CODEC = RecordCodecBuilder.mapCodec(
      instance -> instance.group(
            Ingredient.CODEC
               .listOf()
               .fieldOf("ingredients")
               .forGetter(StockpotRecipe::getIngredients),
            Identifier.CODEC.optionalFieldOf("soup_base", DEFAULT_SOUP_BASE).forGetter(StockpotRecipe::soupBase),
            ItemStackTemplate.CODEC.fieldOf("result").forGetter(StockpotRecipe::result),
            Codec.INT.optionalFieldOf("time", 300).forGetter(StockpotRecipe::time),
            Ingredient.CODEC.optionalFieldOf("carrier", DEFAULT_CARRIER).forGetter(StockpotRecipe::carrier),
            StockpotVisuals.CODEC.forGetter(StockpotRecipe::visuals)
         )
         .apply(instance, StockpotRecipe::new)
   );
   public static final StreamCodec<RegistryFriendlyByteBuf, StockpotRecipe> STREAM_CODEC = StreamCodec.composite(
      Ingredient.CONTENTS_STREAM_CODEC.apply(ByteBufCodecs.list()),
      StockpotRecipe::getIngredients,
      Identifier.STREAM_CODEC,
      StockpotRecipe::soupBase,
      ItemStackTemplate.STREAM_CODEC,
      StockpotRecipe::result,
      ByteBufCodecs.INT,
      StockpotRecipe::time,
      Ingredient.CONTENTS_STREAM_CODEC,
      StockpotRecipe::carrier,
      StockpotVisuals.STREAM_CODEC,
      StockpotRecipe::visuals,
      StockpotRecipe::new
   );

   public static RecipeHolder<StockpotRecipe> getEmptyRecipe() {
      StockpotRecipe stockpotRecipe = new StockpotRecipe(
         Lists.newArrayList(), DEFAULT_SOUP_BASE, new ItemStackTemplate(Items.BOWL), 300, DEFAULT_CARRIER, StockpotVisuals.DEFAULT
      );
      return new RecipeHolder(ResourceKey.create(Registries.RECIPE, EMPTY_ID), stockpotRecipe);
   }

   public MapCodec<StockpotRecipe> codec() {
      return CODEC;
   }

   public StreamCodec<RegistryFriendlyByteBuf, StockpotRecipe> streamCodec() {
      return STREAM_CODEC;
   }
}
