package com.github.ysbbbbbb.kaleidoscopecookery.event;

import com.github.ysbbbbbb.kaleidoscopecookery.advancements.critereon.ModEventTrigger;
import com.github.ysbbbbbb.kaleidoscopecookery.blockentity.decoration.FruitBasketBlockEntity;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModTrigger;
import com.github.ysbbbbbb.kaleidoscopecookery.init.tag.TagMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.EntityInteract;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.RightClickBlock;

@EventBusSubscriber(modid = "kaleidoscope_cookery")
public class RightClickEvent {
   @SubscribeEvent
   public static void onRightClickBlock(RightClickBlock event) {
      Level level = event.getLevel();
      BlockPos pos = event.getPos();
      Player player = event.getEntity();
      InteractionHand hand = event.getHand();
      ItemStack itemInHand = player.getItemInHand(hand);
      Item item = itemInHand.getItem();
      Item maidItem = (Item)BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("touhou_little_maid", "smart_slab_has_maid"));
      if (player.isSecondaryUseActive()
         && hand == InteractionHand.MAIN_HAND
         && !itemInHand.is(Items.DEBUG_STICK)
         && !itemInHand.is(Items.FIREWORK_ROCKET)
         && (maidItem == null || !itemInHand.is(maidItem))
         && level.getBlockEntity(pos) instanceof FruitBasketBlockEntity fruitBasketBlock) {
         if (item instanceof BlockItem) {
            Direction clickedFace = event.getFace();
            if (clickedFace != Direction.UP) {
               return;
            }
         }

         fruitBasketBlock.takeOut(player);
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onRightClickEntity(EntityInteract event) {
      Player player = event.getEntity();
      Entity target = event.getTarget();
      Level level = event.getLevel();
      if (target instanceof Chicken chicken && chicken.isBaby() && player.getMainHandItem().is(TagMod.CATERPILLARS)) {
         chicken.setAge(0);
         if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HEART, chicken.getX(), chicken.getY() + 0.25, chicken.getZ(), 5, 0.2, 0.1, 0.2, 0.1);
            serverLevel.playSound(
               null,
               chicken.getX(),
               chicken.getY(),
               chicken.getZ(),
               SoundEvents.PARROT_EAT,
               chicken.getSoundSource(),
               1.0F,
               1.0F + (serverLevel.getRandom().nextFloat() - serverLevel.getRandom().nextFloat()) * 0.2F
            );
         }

         player.getMainHandItem().shrink(1);
         ((ModEventTrigger)ModTrigger.EVENT.get()).trigger(player, "use_caterpillar_feed_chicken");
      }
   }
}
