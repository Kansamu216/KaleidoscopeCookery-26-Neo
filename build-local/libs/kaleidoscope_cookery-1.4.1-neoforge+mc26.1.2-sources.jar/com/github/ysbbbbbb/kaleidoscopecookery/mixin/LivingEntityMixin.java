package com.github.ysbbbbbb.kaleidoscopecookery.mixin;

import com.github.ysbbbbbb.kaleidoscopecookery.init.ModEffects;
import com.github.ysbbbbbb.kaleidoscopecookery.init.tag.TagMod;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity {
   protected LivingEntityMixin(EntityType<?> pEntityType, Level pLevel) {
      super(pEntityType, pLevel);
   }

   @Inject(method = "getBlockSpeedFactor", at = @At("HEAD"), cancellable = true)
   private void onGetBlockSpeedFactor(CallbackInfoReturnable<Float> cir) {
      LivingEntity entity = (LivingEntity)(Object)this;
      if (entity.hasEffect(ModEffects.TUNDRA_STRIDER)) {
         BlockState blockState = this.level().getBlockState(this.getBlockPosBelowThatAffectsMyMovement());
         if (blockState.is(TagMod.TUNDRA_STRIDER_SPEED_BLOCKS)) {
            float friction = blockState.getBlock().getFriction();
            cir.setReturnValue(1.1F + Math.max(1.0F - friction, 0.0F) * 0.5F);
         }
      }
   }
}
