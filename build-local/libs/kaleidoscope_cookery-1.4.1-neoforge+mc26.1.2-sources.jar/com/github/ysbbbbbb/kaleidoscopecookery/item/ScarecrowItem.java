package com.github.ysbbbbbb.kaleidoscopecookery.item;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModRegistrationProperties;
import com.github.ysbbbbbb.kaleidoscopecookery.advancements.critereon.ModEventTrigger;
import com.github.ysbbbbbb.kaleidoscopecookery.entity.ScarecrowEntity;
import com.github.ysbbbbbb.kaleidoscopecookery.init.ModTrigger;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class ScarecrowItem extends Item {
   public ScarecrowItem() {
      super(ModRegistrationProperties.itemProperties());
   }

   public InteractionResult useOn(UseOnContext context) {
      Direction face = context.getClickedFace();
      if (face == Direction.DOWN) {
         return InteractionResult.FAIL;
      } else {
         Level level = context.getLevel();
         BlockPlaceContext placeContext = new BlockPlaceContext(context);
         BlockPos clickedPos = placeContext.getClickedPos();
         ItemStack stack = context.getItemInHand();
         Vec3 center = Vec3.atBottomCenterOf(clickedPos);
         AABB aabb = ScarecrowEntity.TYPE.getDimensions().makeBoundingBox(center.x(), center.y(), center.z());
         if (level.noCollision(null, aabb) && level.getEntities(null, aabb).isEmpty()) {
            if (level instanceof ServerLevel serverLevel) {
               Consumer<ScarecrowEntity> consumer = EntityType.createDefaultStackConfig(serverLevel, stack, context.getPlayer());
               ScarecrowEntity scarecrow = (ScarecrowEntity)ScarecrowEntity.TYPE.create(
                  serverLevel, consumer, clickedPos, EntitySpawnReason.SPAWN_ITEM_USE, true, true
               );
               if (scarecrow == null) {
                  return InteractionResult.FAIL;
               }

               float rotation = Mth.floor((Mth.wrapDegrees(context.getRotation() - 180.0F) + 22.5F) / 45.0F) * 45.0F;
               scarecrow.setYRot(rotation);
               scarecrow.setXRot(0.0F);
               serverLevel.addFreshEntityWithPassengers(scarecrow);
               level.playSound(null, scarecrow.getX(), scarecrow.getY(), scarecrow.getZ(), SoundEvents.ARMOR_STAND_PLACE, SoundSource.BLOCKS, 0.75F, 0.8F);
               scarecrow.gameEvent(GameEvent.ENTITY_PLACE, context.getPlayer());
               ((ModEventTrigger)ModTrigger.EVENT.get()).trigger(context.getPlayer(), "place_scarecrow");
            }

            stack.shrink(1);
            return level.isClientSide() ? InteractionResult.SUCCESS : InteractionResult.SUCCESS_SERVER;
         } else {
            return InteractionResult.FAIL;
         }
      }
   }

   public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      tooltip.add(Component.translatable("tooltip.kaleidoscope_cookery.scarecrow").withStyle(ChatFormatting.GRAY));
   }
}
