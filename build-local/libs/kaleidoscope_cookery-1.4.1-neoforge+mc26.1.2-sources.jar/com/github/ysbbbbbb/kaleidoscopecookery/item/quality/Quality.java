package com.github.ysbbbbbb.kaleidoscopecookery.item.quality;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import java.util.function.IntFunction;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ByIdMap;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.ByIdMap.OutOfBoundsStrategy;
import org.jetbrains.annotations.NotNull;

public enum Quality implements StringRepresentable {
   SUPERB(0, "superb", ChatFormatting.GOLD, 0.95, 1.2),
   EXCELLENT(1, "excellent", ChatFormatting.GREEN, 0.82, 0.9),
   STANDARD(2, "standard", ChatFormatting.WHITE, 0.55, 0.6),
   POOR(3, "poor", ChatFormatting.DARK_GRAY, 0.0, 0.3);

   public static final IntFunction<Quality> BY_ID = ByIdMap.continuous(Quality::getId, values(), OutOfBoundsStrategy.ZERO);
   public static final Codec<Quality> CODEC = StringRepresentable.fromEnum(Quality::values);
   public static final StreamCodec<ByteBuf, Quality> STREAM_CODEC = ByteBufCodecs.idMapper(BY_ID, Quality::getId);
   private final int id;
   private final String name;
   private final ChatFormatting color;
   private final double score;
   private final double ratio;

   private Quality(int id, String name, ChatFormatting color, double score, double ratio) {
      this.id = id;
      this.name = name;
      this.color = color;
      this.score = score;
      this.ratio = ratio;
   }

   public int getId() {
      return this.id;
   }

   @NotNull
   public String getSerializedName() {
      return this.name;
   }

   public ChatFormatting getColor() {
      return this.color;
   }

   public double getScore() {
      return this.score;
   }

   public double getRatio() {
      return this.ratio;
   }

   public MutableComponent getTooltip() {
      String key = "tooltip.kaleidoscope_cookery.cuisine_quality.%s".formatted(this.name);
      return Component.translatable(key).withStyle(this.color);
   }
}
